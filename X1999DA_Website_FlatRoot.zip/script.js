function showCM() {
  document.getElementById("cmArea").innerHTML = "CM01 체결 완료: 현재 대화 흐름이 시작됩니다.";
}
